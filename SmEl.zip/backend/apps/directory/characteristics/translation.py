from modeltranslation.translator import TranslationOptions, register  # type: ignore

from .models import (
    Characteristic,
    CharacteristicGroup,
    Unit,
    CharacteristicValue,
)

@register(CharacteristicGroup)
class CharacteristicGroupTranslationOptions(TranslationOptions):
    fields = (
        "chg_name",
        "chg_description",
    )

@register(Unit)
class UnitTranslationOptions(TranslationOptions):

    fields = (
        "unt_name",
    )

@register(Characteristic)
class CharacteristicTranslationOptions(TranslationOptions):
    fields = (
        "chr_name",
        "chr_description",
    )

@register(CharacteristicValue)
class CharacteristicValueTranslationOptions(TranslationOptions):
    fields = (
        "cv_description",
    )