from django.utils.translation import gettext_lazy as _
from apps.directory.forms import UniqueTranslatedNameForm
from .models import Characteristic, CharacteristicGroup, Unit, CharacteristicValue
from django import forms

class CharacteristicGroupForm(UniqueTranslatedNameForm):
    name_fields = ("chg_name_en", "chg_name_ru", "chg_name_uk")
    duplicate_message = _("A characteristic group with this name already exists.")

    class Meta:
        model = CharacteristicGroup
        fields = "__all__"


class UnitForm(UniqueTranslatedNameForm):
    name_fields = ("unt_name_en", "unt_name_ru", "unt_name_uk")
    duplicate_message = _("A unit with this name already exists.")

    class Meta:
        model = Unit
        fields = "__all__"


class CharacteristicForm(UniqueTranslatedNameForm):
    name_fields = ("chr_name_en", "chr_name_ru", "chr_name_uk")
    duplicate_message = _("A characteristic with this name already exists.")

    class Meta:
        model = Characteristic
        fields = "__all__"

class CharacteristicValueForm(forms.ModelForm):
    name_fields = ("cv_value_en", "cv_value_ru", "cv_value_uk")
    duplicate_message = _("A characteristic value with this name already exists.")

    class Meta:
        model = CharacteristicValue
        fields = "__all__"
